from django.apps import AppConfig


class LossConfig(AppConfig):
    name = 'loss'
