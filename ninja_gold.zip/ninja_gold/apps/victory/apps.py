from django.apps import AppConfig


class VictoryConfig(AppConfig):
    name = 'victory'
